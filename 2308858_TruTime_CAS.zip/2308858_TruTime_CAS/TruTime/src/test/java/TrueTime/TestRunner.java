package TrueTime;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = "C:\\Users\\2309094\\eclipse-workspace\\TruTime\\FeatureFile\\Feature.feature", 
glue = "stepDefinitions",
plugin= {"pretty",
		"html:Reports/myCucumberReport.html",
		"rerun:target/rerun.txt",
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
}
)
public class TestRunner extends AbstractTestNGCucumberTests {
    // No need to write any code here
}
