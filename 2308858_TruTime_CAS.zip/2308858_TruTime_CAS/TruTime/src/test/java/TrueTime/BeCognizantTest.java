package TrueTime;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import PageObject.BeCognizant;
import BasePage.BasePage;

public class BeCognizantTest extends BasePage{
	//public BeCognizantTest beCTS;
	//public WebDriver driver;
	public BeCognizantTest() throws IOException {
		super();
	}
	@BeforeTest
	public void AccessToMainPage() throws InterruptedException {
	    driver = getDriver();
	    driver.get(getURL());
	}
	@Test
	public void getInfo() throws IOException, InterruptedException {
		BeCognizant beCTS = new BeCognizant(driver);
		Thread.sleep(5000);
		beCTS.clickAccDetails();
		beCTS.getAccManagerName();
		beCTS.getAccManagerEmail();
		Thread.sleep(15000);
		beCTS.verifyOneCogni();
		beCTS.clickOnOneCogni();
		beCTS.takeScreenShot();
	}
	
	
	
}
