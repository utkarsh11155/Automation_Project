package TrueTime;

import java.io.IOException;

import org.testng.annotations.Test;

import BasePage.BasePage;
import PageObject.OneCognizant;


public class OneCognizantTest extends BasePage{

	public OneCognizantTest() throws IOException {
		super();
		
	}
	String txt = "Trutime";
	@Test
	public void OneC() throws InterruptedException, IOException {
		OneCognizant oneC = new OneCognizant(driver);
		oneC.handleAnotherTab();
		oneC.clickOnSearchChrome();
		oneC.searchTruTimeChrome(txt);
		oneC.verifyTruTimePage();
		oneC.takeScreenShot();
		
	}
	

}
