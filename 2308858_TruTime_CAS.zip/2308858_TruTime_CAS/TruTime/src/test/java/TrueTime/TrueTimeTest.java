package TrueTime;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import BasePage.BasePage;
import PageObject.TruTime;
import UtilityMethods.CalenderDDMMYYY;

public class TrueTimeTest extends BasePage{

	public TrueTimeTest() throws IOException {
		super();
		
	}

	TruTime trueT;
	CalenderDDMMYYY dmy = new CalenderDDMMYYY();
	
	//retrieving date and validating
	@Test(priority = 1)
	public void validateCurrentMonthAndYear() {
		trueT = new TruTime(driver);
		SoftAssert asrt = new SoftAssert();
		asrt.assertEquals(trueT.getMonth(), dmy.localCurrentMonth());
		asrt.assertEquals(trueT.getYear(), dmy.localCurrentYear());
		asrt.assertAll();
		try {
			trueT.takeScreenShot();
		} catch (IOException e) {
			System.out.println("Screenshot not taken");
		}
	}
	
	//retrieving backdated date and validating
	@Test(priority = 2)
	public void validateBackDatedTopUp() {
		Assert.assertEquals(trueT.backDatedTopUp(), dmy.date15DaysBefore());
	}
	
	//validating legends
	@Test(priority = 3)
	public void printLegends() {
		Assert.assertEquals(trueT.getLegends(),15);
	}
	
	//validating highlighted day
	@Test(priority = 4)
	public void validateCurrentHighlightedDate() {
		Assert.assertEquals(trueT.getCurrentHighlightedDay(), dmy.localHighlightedDayDateFormat());
	}
	
	//validating week days
	@Test(priority = 5)
	public void validateTruTimeDates() {
		
		Assert.assertEquals(trueT.getCurrentWeekDatesInTruTime(), true);
	}
	

}
