package TrueTime;

import java.io.IOException;

import io.cucumber.java.en.*;
import BasePage.BasePage;
import PageObject.OneCognizant;
import TrueTime.BeCognizantTest;
import TrueTime.OneCognizantTest;
import TrueTime.TrueTimeTest;

public class MySteps extends BasePage{
	
	public MySteps() throws IOException {
		super();
	}
	BeCognizantTest baseTest = new BeCognizantTest();
	
	
	@Given("Launching user BeCognizant page")
	public void launching_user_be_cognizant_page() throws InterruptedException {
		
		baseTest.AccessToMainPage();
	}

	@Then("Verifying details present on BeCognizant page and clicking OneCognizant")
	public void verifying_details_present_on_be_cognizant_page_and_clicking_one_cognizant() throws IOException {
		BeCognizantTest beCogni = new BeCognizantTest();
		try {
			beCogni.getInfo();
			//beCogni.verifyOneCogni();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	@Then("Searching TruTime on OneCognizant and verifying TruTime page")
	public void searching_tru_time_on_one_cognizant_and_verifying_tru_time_page() throws InterruptedException, IOException {
	   OneCognizantTest oneCogni = new OneCognizantTest();
	   
		oneCogni.OneC();
		//oneCogni.validateTruTimePage();
	
	}

	@Then("Verifying details present on TruTime page")
	public void verifying_details_present_on_tru_time_page() throws IOException {
		TrueTimeTest truTime = new TrueTimeTest();
		truTime.validateCurrentMonthAndYear();
		truTime.validateBackDatedTopUp();
		truTime.printLegends();
		truTime.validateCurrentHighlightedDate();
		truTime.validateTruTimeDates();
	}

	@Then("Closing the browser")
	public void closing_the_browser() {
		baseTest.destroy();
	}
}