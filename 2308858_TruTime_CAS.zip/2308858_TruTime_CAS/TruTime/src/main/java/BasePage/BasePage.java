package BasePage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
public class BasePage {
   
	// Static WebDriver instance shared across all page objects
	public static WebDriver driver;
	private String url;
	private Properties prop;
	
	// Constructor to initialize properties from config.properties file
	public BasePage() throws IOException {
		prop = new Properties();
		FileInputStream data = new FileInputStream("./src/main/java/Resources/config.properties");
		prop.load(data);
		
	}
	
	// Method to get the WebDriver instance
	public WebDriver getDriver() {
		if(driver == null) driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		return driver;
	}
	
	// Method to get the base URL from config.properties
	public String getURL() {
		url=prop.getProperty("url");
		return url;
	}

	
	// Method to quit the WebDriver instance after test suite execution
	@AfterTest
	public void destroy() {
		driver.quit();
	}
}
