package PageObject;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OneCognizant {
	public WebDriver driver;
	public static String beHandle, oneCogniHandle;
	
	public OneCognizant(WebDriver driver) {
		this.driver = driver;
	}
	
	//Page elements
	By inpSearch = By.id("oneC_searchAutoComplete"); //chrome	
	By searchBtn = By.className("searchTopBar"); //edge
	By inputSearch = By.id("oneCSearchTop"); //edge	
	By btnTruTime = By.xpath("//div[@id = 'newSearchAppsLST']/div[1]/div//div[contains(text(), 'TruTime ')]");
	By txtTruTime = By.xpath("//a[text()='My TruTime']");
	
	
	public void handleAnotherTab() {
		String mainWindowHandle = driver.getWindowHandle();
		Set<String> allWindowHandles = driver.getWindowHandles();
		for(String handle:allWindowHandles) {
			if(!handle.equals(mainWindowHandle)) {
				driver.switchTo().window(handle);
				return;
			}
		}
	}
	
	//Click search input
	public void clickOnSearchChrome() {
		driver.findElement(inpSearch).click();
	}
	
	//Search True Time
	public void searchTruTimeChrome(String txt) throws InterruptedException, IOException {
		driver.findElement(inpSearch).sendKeys(txt);  
		Thread.sleep(5000);
		
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait1.until(ExpectedConditions.elementToBeClickable(btnTruTime));
		driver.findElement(btnTruTime).click();
		Thread.sleep(5000);
	}
	
	
	
	//Switching to frame
	public boolean verifyTruTimePage() throws InterruptedException {
		driver.switchTo().frame("appFrame");
		
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement truTimeEle = wait2.until(ExpectedConditions.visibilityOfElementLocated(txtTruTime));
		Thread.sleep(4000);
		String truTime = driver.findElement(txtTruTime).getText();
		System.out.println(truTime);
		if(truTime.equals("My TruTime")) {
			System.out.println("TruTime Displayed");
		}
		return false;
		
		//return truTimeEle.isDisplayed();
	}
	
	//Method to take screenshot
	public void takeScreenShot() throws IOException {
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		File dest=new File(System.getProperty("user.dir")+"\\screenshots\\OneCognizant"+".png");		
		FileUtils.copyFile(src,dest);
	}
}
